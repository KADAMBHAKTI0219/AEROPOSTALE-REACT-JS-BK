import React from 'react'

const AddToCart = () => {
  return (
    <div>
      
    </div>
  )
}

export default AddToCart
