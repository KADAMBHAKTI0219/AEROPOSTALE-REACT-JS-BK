import React from 'react'

const CartPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default CartPage
