import React, { useState } from 'react'

const Card = ({product}) => {
    const [currentColor, setCurrentColor] = useState(product.colors);
    console.log(currentColor)
      const handleColorChange = (el) => {
        setCurrentColor(el);
      };
    
  return (
    <div className="product">
        <div className="display-img">
        <img src={currentColor.image} alt={product.title} height={400} width={400} />
        <img src={currentColor.image2} alt={product.title} height={400} width={400} />
        <img src={currentColor.image3} alt={product.title} height={400} width={400} />
        <img src={currentColor.image4} alt={product.title} height={400} width={400} />
        </div>

        <h2>{product.title}</h2>
        <p>{product.price}</p>
        <div className="color-options">
          {product.colors.map((el, index) => (
          
            <button
              key={index}
style={{backgroundColor:el.color}}
              onClick={() => handleColorChange(el)}
            ></button>
          ))}
        </div>
      </div>
  )
}

export default Card
