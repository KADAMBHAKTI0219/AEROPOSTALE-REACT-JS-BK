import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import Card from './Card'

const Description = () => {
  const {id} =useParams()
  const [singleProductData,setSingleProductData] = useState()
  const getSingleProductData = (id)=>{
      axios.get(`http://localhost:3000/products/${id}`).then((res)=>setSingleProductData(res.data)).catch(err=>console.log(err))
  }

  useEffect(()=>{
    getSingleProductData(id)
  },[])
  return (
    <div>
      <div>
          {
            singleProductData.map((el)=>(
              <Card key={id} product={el} />
            ))
          }

        <button><Link to={"/addToCart"}>Add To Cart</Link></button>
      </div>
    </div>
  )
}

export default Description
